<?php $__env->startSection('contents'); ?>
<div class="container-fluid px-lg-5 py-4 skip-nav" style="min-height: 700px">
    <div class="row">
        <div class="col-lg-3 pt-lg-3">
            <div class="side-bar">
                <p class="text-brand-dark py-3 px-lg-2 bg-brand"><a href="<?php echo e(route('frontend::about')); ?>">Who We Are</a></p>
                <p class="text-brand-dark py-3 px-lg-2 bg-brand"><a class="text-brand-dark" href="<?php echo e(route('frontend::management')); ?>">Management</a></p>
            </div>
        </div>
        <div class="col-md-9 pt-lg-3">
            <div class="details-text">
                <h3 class="title color-brand">Who We Are</h3>
                <img loading="lazy" src="<?php echo e(asset($datas->image)); ?>" class="directors float-lg-end d-block" style="width: 30%; padding-left: 25px;" />
                <?php echo $datas->description; ?>

            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifadgrou/public_html/group/resources/views/frontend/about/index.blade.php ENDPATH**/ ?>