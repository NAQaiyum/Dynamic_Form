<?php $__env->startSection('contents'); ?>
<section class="skip-nav">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="contact-page-banner">
                    <img class="w-100" src="<?php echo e(asset('frontend/assets/contact/banner.png')); ?>" />
                </div>
            </div>
            <div class="col-md-12">
                <div class="contact-page">
                    <div class="contact-text">
                        <div class="twelve">
                            <h2 style="color: white;"> Contact US </h2>
                        </div>
                    </div>
                    <div class="contact-form">
                        <h3> Get in touch</h3>
                        
                        <ul>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php echo e($company->id == $datas->id ? 'active' : null); ?>"><a href="<?php echo e(route('frontend::contact',['slug'=>$company->slug])); ?>"><?php echo e($company->name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="address">
                            <p>
                                <strong>Address : </strong>
                                <span class="px-2"><?php echo e($datas->address); ?></span>
                            </p>
                            <p>
                                <strong>Email : </strong>
                                <span class="px-2"><a href="mailto:<?php echo e($datas->email); ?>"><?php echo e($datas->email); ?></a></span>
                                <strong>Phone : </strong>
                                <span class="px-2"><?php echo e($datas->phone); ?></span>
                            </p>
                        </div>

                        <hr />
                        <?php if(Session::has('message')): ?>
                        <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>">
                            <?php echo e(Session::get('message')); ?>

                            <span style="float:right;cursor:pointer;" onclick="hideAlert()"><i class="fas fa-times-circle"></i></span>
                        </p>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('frontend::message.send')); ?>"  enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Name *</label>
                                        <input type="text" class="form-control" name="name" />
                                        <input type="hidden" class="form-control" name="company_id" value=<?php echo e($datas->id); ?> />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Phone *</label>
                                        <input type="number" class="form-control" name="phone" />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email </label>
                                        <input type="email" class="form-control" name="email" />
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Subject *</label>
                                        <input type="text" class="form-control" name="subject" />
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Message</label>
                                        <textarea rows="8" class="form-control" name="message" ></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-2">
                                    
                                    
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-12">
                                    <center>
                                        <button type="submit" class="btn btn-primary btn-submit"> Submit </button>
                                    </center>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
    ul .active{
        background: #f58220;
    }
    ul .active a{
        color:white;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
  function hideAlert(){
    $(".alert").hide();
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asiaticexp/Sites/www/comProjects/ifad/ifadweb/resources/views/frontend/contact/index.blade.php ENDPATH**/ ?>