<section class="block-inner" style="background-image : url(<?php echo e($data && $data->cover ? asset($data->cover) : null); ?>)">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h1 style="color:white"><?php echo e($data->title); ?></h1>
                <div class="breadcrumbs">
                    <ul>
                        <li><i class="pe-7s-home"></i> <a href="<?php echo e(route('frontend::home')); ?>" title="">Home</a></li>
                        <li><a href="#" title=""><?php echo e($data->title); ?></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH /Applications/MAMP/htdocs/comProjects/riseofbang/resources/views/frontend/news/includes/header.blade.php ENDPATH**/ ?>