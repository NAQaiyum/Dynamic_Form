<!-- Vendor js -->
<script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>

<!-- App js-->
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<?php echo $__env->yieldContent('js'); ?>
<?php echo notifyJs(); ?><?php /**PATH /Users/asiaticexp/Sites/www/comProjects/ifadweb/resources/views/layouts/js.blade.php ENDPATH**/ ?>