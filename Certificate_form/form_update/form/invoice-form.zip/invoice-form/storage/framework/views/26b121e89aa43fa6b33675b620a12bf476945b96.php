<?php $__env->startSection('contents'); ?>
<div class="container-fluid px-lg-5 pt-5 py-lg-4" id="social-media" style="min-height:750px;">
  <div class="row pt-5">
    <div class="col-md-8 offset-md-2 offset-sm-2 offset-xs-2 text-center company-logos-text">
      <h2 class="color-brand pt-5 ">Social Media Feed</h2>
      <!-- <p class="text-brand-dark"></p> -->
    </div>
  </div>
  <div class="row py-3">
    <?php $__currentLoopData = $getSocial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 py-2 px-3 animateit">
      <div class="media">
        <div class="media-image">
          <div class="image-overlay">
            <a target="_blank" href="<?php echo e(asset($social->ref)); ?>">
              <img loading="lazy" src="<?php echo e(asset($social->thumbnail)); ?>" class="image img-fluid" />
            </a>
          </div>
        </div>
        <div class="media-text text-brand-dark pt-3">
          <p><?php echo e($social->title); ?></p>
        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
    .gallery{
        cursor: pointer;
        transition: transform .2s;
    }
    .gallery:hover{
        transform: scale(1.03);
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/optaefuh/public_html/sandbox/ifad-final/resources/views/frontend/news/social.blade.php ENDPATH**/ ?>