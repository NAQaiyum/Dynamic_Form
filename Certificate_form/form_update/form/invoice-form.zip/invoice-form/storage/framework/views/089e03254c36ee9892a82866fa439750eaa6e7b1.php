<form method="POST" action="<?php echo e(route('news::save')); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title"><?php echo e($title); ?></h4>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
            <div class="row">
                <div class="col-md-4">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Cover <span style="color:tomato">(600X400)</span></label> <br />
                        <img src="<?php echo e(asset($data ? $data->cover : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="cover">
                        <input type="file" class="form-control" accept="image/png, image/gif, image/jpeg" name="cover" onchange="document.getElementById('cover').src = window.URL.createObjectURL(this.files[0])">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Thumbnail <span style="color:tomato">(600X400)</span></label> <br />
                        <img src="<?php echo e(asset($data ? $data->thumbnail : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="thumbnail">
                        <input type="file" class="form-control" accept="image/png, image/gif, image/jpeg" name="thumbnail" onchange="document.getElementById('thumbnail').src = window.URL.createObjectURL(this.files[0])">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Images <span style="color:tomato">(350X250)</span></label> <br />
                        <img src="<?php echo e(asset($data && count($data->images) > 0 ? $data->images[0]->image : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="image">
                        <input type="file" class="form-control" accept="image/png, image/gif, image/jpeg" name="image[]" onchange="document.getElementById('image').src = window.URL.createObjectURL(this.files[0])" multiple>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Title</label>
                        <input type="text" class="form-control" name="title" placeholder="News Title" value="<?php echo e($data ? $data->title : null); ?>">
                        <input type="hidden" class="form-control" name="id" placeholder="" value="<?php echo e($data ? $data->id : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Sub Title</label>
                        <input type="text" class="form-control" name="sub_title" placeholder="Sub Title" value="<?php echo e($data ? $data->sub_title : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">News Published Date</label>
                        <input type="date" class="form-control" name="news_date" placeholder="News Published Date" value="<?php echo e($data ? $data->news_date : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Author</label>
                        <input type="text" class="form-control" name="author" placeholder="Author" value="<?php echo e($data ? $data->author : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Web Ref</label>
                        <input type="text" class="form-control" name="ref" placeholder="Web Ref" value="<?php echo e($data ? $data->ref : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Tag</label>
                        <select class="form-control" name="tag">
                            <option value=""> Select Tag </option>
                            <option value="1" <?php echo e($data && $data->tag == 1 ? 'selected': null); ?>> News & Events</option>
                            <option value="2" <?php echo e($data && $data->tag == 2 ? 'selected': null); ?>> Social feed </option>
                        </select>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mt-1 mb-1">
                        <input type="checkbox" id="show_home" name="show_home" value="1" <?php echo e($data && $data->show_home == 1 ? 'checked' : null); ?>>
                        <label for="field-1" class="form-label">Show home</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Placement</label>
                        <input type="number" class="form-control" name="placement" placeholder="Placement" value="<?php echo e($data ? $data->placement : null); ?>">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Description</label>
                        <textarea class="form-control" name="description" id="description" rows="10"><?php echo e($data ? $data->description : null); ?></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-info waves-effect waves-light">Save changes</button>
        </div>
    </div>
</form>
<script>
    ClassicEditor
        .create( document.querySelector( '#description' ))
        .catch( error => {
            console.error( error );
        });
</script><?php /**PATH /home/ifadgrou/public_html/resources/views/admin/news-events/form.blade.php ENDPATH**/ ?>