<form method="POST" action="<?php echo e(route('news::save')); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php 
        $dataCat = $data ? $data->newsCategory : [];
        $dataType = $data ? $data->newsType : [];
        $type_id = [];
        $cat_id     = [];
        if($dataCat){
            foreach($dataCat as $cat){
                $cat_id[] = $cat->cat_id;
            }
        }
        if($dataType){
            foreach($dataType as $type){
                $type_id[] = $type->type_id;
            }
        }
        
    ?>
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title"><?php echo e($title); ?></h4>
            <button type="button" class="btn-close fas fa-times" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
            <div class="row">
                <div class="col-md-4">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Cover <span style="color:tomato">(16:9)</span></label> <br />
                        <img src="<?php echo e(asset($data ? $data->cover : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="cover">
                        <input type="file" class="form-control" accept="image/png, image/gif, image/jpeg" name="cover" onchange="document.getElementById('cover').src = window.URL.createObjectURL(this.files[0])">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Thumbnail <span style="color:tomato">(4:3)</span></label> <br />
                        <?php if($data && $data->thumbnail): ?>
                        <img src="<?php echo e(asset($data ? $data->thumbnail : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="thumbnail">
                        <?php else: ?>
                        <img src="<?php echo e(asset($data ? $data->image : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="thumbnail">
                        <?php endif; ?>
                        <input type="file" class="form-control" accept="image/png, image/gif, image/jpeg" name="thumbnail" onchange="document.getElementById('thumbnail').src = window.URL.createObjectURL(this.files[0])">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Images <span style="color:tomato">(4:3)</span></label> <br />
                        <img src="<?php echo e(asset($data && count($data->images) > 0 ? $data->images[0]->image : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="image">
                        <input type="file" class="form-control" accept="image/png, image/gif, image/jpeg" name="image[]" onchange="document.getElementById('image').src = window.URL.createObjectURL(this.files[0])" multiple>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Title</label>
                        <input type="text" class="form-control" name="title" placeholder="News Title" value="<?php echo e($data ? $data->title : null); ?>">
                        <?php if($content_id): ?>
                        <input type="hidden" class="form-control" name="content_id" placeholder="" value="<?php echo e($data ? $data->id : null); ?>">
                        <?php else: ?>
                        <input type="hidden" class="form-control" name="id" placeholder="" value="<?php echo e($data ? $data->id : null); ?>">
                        <?php endif; ?>
                        
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Sub Title</label>
                        <input type="text" class="form-control" name="sub_title" placeholder="Sub Title" value="<?php echo e($data ? $data->sub_title : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">News Published Date</label>
                        <input type="date" class="form-control" name="news_date" placeholder="News Published Date" value="<?php echo e($data ? $data->news_date : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Author</label>
                        <input type="text" class="form-control" name="author" placeholder="Author" value="<?php echo e($data ? $data->author : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Web Ref</label>
                        <input type="text" class="form-control" name="ref" placeholder="Web Ref" value="<?php echo e($data ? $data->ref : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Placement</label>
                        <input type="number" class="form-control" name="placement" placeholder="Placement" value="<?php echo e($data ? $data->placement : null); ?>">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Video Link (Youtube, Vimeo)</label>
                        <textarea class="form-control" name="video" placeholder="Insert Your Video Link"><?php echo e($data ? $data->video : null); ?></textarea>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="bg-warning pt-2 pb-1 mt-2 mb-1">
                        <p for="field-1" class="form-label text-white text-center" style="">News Type</p>
                    </div>
                    <div class="row">
                        <div class="col-md-3">
                            <input type="checkbox" name="news_type[]" value="1" <?php echo e(in_array(1,$type_id) ? 'Checked' : null); ?>>
                            <label for="field-1" class="form-label">Featured</label>
                        </div>
                        <div class="col-md-3">
                            <input type="checkbox" name="news_type[]"value="2" <?php echo e(in_array(2,$type_id) ? 'Checked' : null); ?>>
                            <label for="field-1" class="form-label">Latest News</label>
                        </div>
                        <div class="col-md-4">
                            <input type="checkbox" name="news_type[]" value="3" <?php echo e(in_array(3,$type_id) ? 'Checked' : null); ?>>
                            <label for="field-1" class="form-label">Recent</label>
                        </div>
                        <div class="col-md-4">
                            <input type="checkbox" name="news_type[]" value="4" <?php echo e(in_array(4,$type_id) ? 'Checked' : null); ?>>
                            <label for="field-1" class="form-label">Custom Content</label>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    
                    <div class="bg-primary pt-2 pb-1 mt-2 mb-1">
                        <p for="field-1" class="form-label text-white text-center" style="">News Categories</p>
                    </div>
                    <div class="row">
                        <?php $__currentLoopData = $getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3">
                            <input type="checkbox" id="category_id_<?php echo e($category->id); ?>" name="category_id[]" value="<?php echo e($category->id); ?>" <?php echo e(in_array($category->id,$cat_id) ? 'Checked' : null); ?>>
                            <label for="category_id_<?php echo e($category->id); ?>" class="form-label"><?php echo e($category->title); ?></label>

                            <div class="row pl-1">
                                <div class="col-12" style="margin-left: 15px;">
                                <?php $__currentLoopData = $category->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="checkbox" id="category_id_<?php echo e($child->id); ?>" name="category_id[]" value="<?php echo e($child->id); ?>" <?php echo e(in_array($child->id,$cat_id) ? 'Checked' : null); ?>>
                                <label for="category_id_<?php echo e($child->id); ?>" class="form-label"><?php echo e($child->title); ?></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="mb-1">
                        <label for="field-1" class="form-label">Description</label>
                        <textarea class="form-control" name="description" id="description" style="min-height: 100px"><?php echo e($data ? $data->description : null); ?></textarea>
                        <div id="word-count"></div>
                    </div>
                </div>
                <div class="col-md-12">
                    
                    <div class="bg-danger pt-2 pb-1 mt-2 mb-1">
                        <p for="field-1" class="form-label text-white text-center" style="">News SEO</p>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <label for="field-1" class="form-label">Meta Title</label>
                            <input type="text" class="form-control" name="meta_title" placeholder="Meta Title" value="<?php echo e($data && $data->seo ? $data->seo->title : null); ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="field-1" class="form-label">Meta Tags</label>
                            <input type="text" class="form-control" name="meta_tag" placeholder="Meta Tags" value="<?php echo e($data && $data->seo ? $data->seo->tag : null); ?>">
                        </div>
                        <div class="col-md-12">
                            <label for="field-1" class="form-label">Meta Description</label>
                            <textarea class="form-control" name="meta_description" rows="3"><?php echo e($data && $data->seo ? $data->seo->description : null); ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label for="field-1" class="form-label">Meta Image</label>
                            <img src="<?php echo e(asset($data && $data->seo ? $data->seo->image : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="meta_image">
                            <input type="file" class="form-control" accept="image/png, image/gif, image/jpeg" name="meta_image" onchange="document.getElementById('meta_image').src = window.URL.createObjectURL(this.files[0])" multiple>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-info waves-effect waves-light">Save changes</button>
        </div>
    </div>
</form>
<script>
    ClassicEditor
        .create( document.querySelector( '#description' ),{
            mediaEmbed: {
                previewsInData:true
            },
            ckfinder: {
                uploadUrl: '<?php echo e(route('ckeditor::upload').'?_token='.csrf_token()); ?>'
            }
        })
        .catch( error => {
            console.error( error );
        });
        
</script><?php /**PATH /Applications/MAMP/htdocs/comProjects/riseofbang/resources/views/admin/news-events/form.blade.php ENDPATH**/ ?>