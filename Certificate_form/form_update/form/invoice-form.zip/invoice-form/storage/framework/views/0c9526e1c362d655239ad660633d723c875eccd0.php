<?php $__env->startSection('contents'); ?>
<div class="container-fluid px-lg-5 py-4 skip-nav" style="min-height: 700px">
    <div class="row">
        <div class="col-md-12 pt-lg-3">
            <div class="details-text">
                <h3 class="title color-brand"><?php echo e($datas->title); ?></h3>
                <div>
                <?php echo $datas->description; ?>

                </div>
            </div>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifadgrou/public_html/resources/views/frontend/privacy/index.blade.php ENDPATH**/ ?>