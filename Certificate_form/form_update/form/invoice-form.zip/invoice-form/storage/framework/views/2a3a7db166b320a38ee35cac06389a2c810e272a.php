<div class="mobile-menu-area navbar-fixed-top hidden-sm hidden-md hidden-lg">
    <nav class="mobile-menu" id="mobile-menu">
        <div class="sidebar-nav">
            <ul class="nav side-menu">
                <!-- <li class="sidebar-search">
                    <div class="input-group custom-search-form">
                        <input type="text" class="form-control" placeholder="Search...">
                        <span class="input-group-btn">
                                <button class="btn mobile-menu-btn" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                    </div>
                </li> -->
                <li><a href="<?php echo e(route('frontend::home')); ?>">Home</a></li>
                <?php $__currentLoopData = Category(null,'ASC')->where('parent_id', null); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                <?php if($cat->child->count() > 0): ?>
                    <a href="#"><?php echo e($cat->title); ?><span class="fa arrow"></span></a>
                <?php else: ?> 
                    <a href="<?php echo e(route('frontend::news.index',['slug' => $cat->slug])); ?>"><?php echo e($cat->title); ?></a>
                <?php endif; ?>
                    <ul class="nav nav-second-level">
                        <?php $__currentLoopData = $cat->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('frontend::news.index',['slug' => $child->slug])); ?>"><?php echo e($child->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <!-- /.nav-second-level -->
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="#">Blog </a>
                </li>
                <li>
                    <a href="#">Contact </a>
                </li>
                <!-- social icon -->
                <li>
                    <div class="social">
                        <ul>
                            <li><a href="#" class="facebook"><i class="fa  fa-facebook"></i> </a></li>
                            <li><a href="#" class="twitter"><i class="fa  fa-twitter"></i></a></li>
                            <li><a href="#" class="google"><i class="fa  fa-google-plus"></i></a></li>
                        </ul>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
    <div class="container">
        <div class="top_header_icon">
            <span class="top_header_icon_wrap">
                    <a target="_blank" href="#" title="Twitter"><i class="fa fa-twitter"></i></a>
                </span>
            <span class="top_header_icon_wrap">
                    <a target="_blank" href="#" title="Facebook"><i class="fa fa-facebook"></i></a>
                </span>
            <span class="top_header_icon_wrap">
                    <a target="_blank" href="#" title="Google"><i class="fa fa-google-plus"></i></a>
                </span>
            <span class="top_header_icon_wrap">
                    <a target="_blank" href="#" title="Vimeo"><i class="fa fa-vimeo"></i></a>
                </span>
            <span class="top_header_icon_wrap">
                    <a target="_blank" href="#" title="Pintereset"><i class="fa fa-pinterest-p"></i></a>
                </span>
        </div>
        <div id="showLeft" class="nav-icon">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/comProjects/riseofbang/resources/views/layouts/includes/mobileNav.blade.php ENDPATH**/ ?>