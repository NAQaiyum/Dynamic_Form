<div class="office-location">
    <div class="map">
        <!-- Paste the Google Map iframe code here -->
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3650.6857792832407!2d90.39884957507371!3d23.794201187093805!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c70615c9f465%3A0x8ec65d07b2a3b808!2sWhiteshell%20IT%20Shop!5e0!3m2!1sen!2sbd!4v1697018860474!5m2!1sen!2sbd" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/meshkat/car/resources/views/frontend/home/includes/map.blade.php ENDPATH**/ ?>