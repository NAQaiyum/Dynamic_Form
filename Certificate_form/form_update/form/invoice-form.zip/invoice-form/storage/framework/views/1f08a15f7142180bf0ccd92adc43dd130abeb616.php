<form method="POST" action="<?php echo e(route('team::message.save')); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title"><?php echo e($title); ?></h4>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
            <div class="row">
                <div class="col-md-12">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Image <span style="color:tomato">(617X425)</span></label> <br />
                        <img src="<?php echo e(asset($data ? $data->image : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="image">
                        <input type="file" class="form-control" accept="image/png, image/gif, image/jpeg" name="image" onchange="document.getElementById('image').src = window.URL.createObjectURL(this.files[0])">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Team</label>
                        <select class="form-control" name="team_id" >
                            <option value=""> Select Team </option>
                            <?php $__currentLoopData = $getTeam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($team->id); ?>" <?php echo e($data && $data->getTeam && $data->getTeam->id == $team->id ? 'selected' : null); ?> > <?php echo e($team->name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mt-4">
                        <input type="checkbox" id="show_home" name="show_home" value="1" <?php echo e($data && $data->show_home == 1 ? 'checked' : null); ?>>
                        <label for="field-1" class="form-label">Show home</label>
                        <input type="hidden" class="form-control" name="id" placeholder="id" value="<?php echo e($data ? $data->id : null); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Placement</label>
                        <input type="number" class="form-control" name="placement" placeholder="Placement" value="<?php echo e($data ? $data->placement : null); ?>">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Message</label>
                        <textarea name="message" class="form-control"><?php echo e($data ? $data->message : null); ?></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-info waves-effect waves-light">Save changes</button>
        </div>
    </div>
</form><?php /**PATH /home/ifadgrou/public_html/resources/views/admin/team/messages/form.blade.php ENDPATH**/ ?>