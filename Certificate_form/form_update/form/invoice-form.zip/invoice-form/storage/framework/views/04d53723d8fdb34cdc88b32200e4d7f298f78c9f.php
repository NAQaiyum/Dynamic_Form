
<?php $__env->startSection('content'); ?>
<div class="row" style="margin-top: 3.5%;">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="header-title"><?php echo e($title); ?></h4>
                    </div>
                    <div class="col-md-2">
                        <p class="btn btn-primary waves-effect waves-light" data-bs-toggle="modal" data-bs-target="#create"><i class="fa fa-plus"></i> <?php echo e(SiteSetting() ? 'Update' : 'Create'); ?></p>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table id="scroll-horizontal-datatable" class="table w-100 nowrap">
                    <thead>
                        <tr>
                            <th>Logo Header</th>
                            <th>Logo Footer</th>
                            <th>Site Title</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Address</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><img src="<?php echo e(asset(SiteSetting() ? SiteSetting()->logo_header : 'assets/images/logo-light.png')); ?>" style="width:80px;"></td>
                            <td><img src="<?php echo e(asset(SiteSetting() ? SiteSetting()->logo_footer : 'assets/images/logo-light.png')); ?>" style="width:80px;"></td>
                            <td><?php echo e(SiteSetting() ? SiteSetting()->site_title : 'ifad'); ?></td>
                            <td><?php echo e(SiteSetting() ? SiteSetting()->email : null); ?></td>
                            <td><?php echo e(SiteSetting() ? SiteSetting()->phone : null); ?></td>
                            <td><?php echo e(SiteSetting() ? SiteSetting()->address : null); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div id="create" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-lg modal-dialog">
        <form method="POST" action="<?php echo e(route('settings::siteSave')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e($title); ?></h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <?php if(SiteSetting() && SiteSetting()->logo_header): ?>
                                <img src="<?php echo e(asset(SiteSetting()->logo_header)); ?>" id="logo_header" style="height:70px;">
                                <?php else: ?> 
                                <img src="https://www.webcraft.com.mt/assets/img/No-Image-Thumbnail.png" id="logo_header">
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <?php if(SiteSetting() && SiteSetting()->logo_footer): ?>
                                <img src="<?php echo e(asset(SiteSetting()->logo_footer)); ?>" id="logo_footer" style="height:70px;">
                                <?php else: ?> 
                                <img src="https://www.webcraft.com.mt/assets/img/No-Image-Thumbnail.png" id="logo_footer">
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <?php if(SiteSetting() && SiteSetting()->icon): ?>
                                <img src="<?php echo e(asset(SiteSetting()->icon)); ?>" id="icon" style="height:70px;">
                                <?php else: ?> 
                                <img src="https://www.webcraft.com.mt/assets/img/No-Image-Thumbnail.png" id="icon">
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="field-1" class="form-label">Logo Header (180X50)</label>
                                <input type="file" class="form-control" name="logo_header" onchange="document.getElementById('logo_header').src = window.URL.createObjectURL(this.files[0])">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="field-1" class="form-label">Logo Footer (180X50)</label>
                                <input type="file" class="form-control" name="logo_footer" onchange="document.getElementById('logo_footer').src = window.URL.createObjectURL(this.files[0])">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="field-1" class="form-label">Icon (70X70)</label>
                                <input type="file" class="form-control" name="icon" onchange="document.getElementById('icon').src = window.URL.createObjectURL(this.files[0])">
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="field-1" class="form-label">Title</label>
                                <input type="text" class="form-control" name="site_title" placeholder="Site Title" value="<?php echo e(SiteSetting() ? SiteSetting()->site_title : null); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="field-1" class="form-label">Phone</label>
                                <input type="text" class="form-control" name="phone" placeholder="Site Phone" value="<?php echo e(SiteSetting() ? SiteSetting()->phone : null); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="field-1" class="form-label">Email</label>
                                <input type="text" class="form-control" name="email" placeholder="Site Email" value="<?php echo e(SiteSetting() ? SiteSetting()->email : null); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="field-2" class="form-label">Address</label>
                                <input type="text" class="form-control" name="address" placeholder="Site address" value="<?php echo e(SiteSetting() ? SiteSetting()->address : null); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="field-2" class="form-label">No of Employees</label>
                                <input type="text" class="form-control" name="no_employee" placeholder="Site address" value="<?php echo e(SiteSetting() ? SiteSetting()->no_employee : null); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="field-2" class="form-label">No of Companies</label>
                                <input type="text" class="form-control" name="no_companies" placeholder="Site address" value="<?php echo e(SiteSetting() ? SiteSetting()->no_companies : null); ?>">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="field-2" class="form-label">No of Export Products</label>
                                <input type="text" class="form-control" name="no_customers" placeholder="Site address" value="<?php echo e(SiteSetting() ? SiteSetting()->no_customers : null); ?>">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="field-1" class="form-label">Video</label>
                                <textarea class="form-control" name="video" placeholder="Company Video"><?php echo e(SiteSetting() && SiteSetting()->video ? SiteSetting()->video : null); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary waves-effect" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-info waves-effect waves-light">Save changes</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/datatables.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/optaefuh/public_html/sandbox/ifad-final/resources/views/admin/settings/site.blade.php ENDPATH**/ ?>