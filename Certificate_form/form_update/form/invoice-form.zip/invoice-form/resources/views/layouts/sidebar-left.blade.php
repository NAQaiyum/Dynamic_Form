<div class="left-side-menu">
    <div class="h-100" data-simplebar>
    
    <div id="sidebar-menu">
        <ul id="side-menu">
            <li class="menu-title">Navigation</li>
            <li>
                <a href="{{route('dashboard')}}">
                    <i class="fas fa-tachometer-alt"></i>
                    <span> Dashboard </span>
                </a>
            </li>
            
            <li class="menu-title mt-2">Apps</li>
            <li>
                <a href="#">
                    <i class="fas fa-images"></i>
                    <span> Invoices </span>
                </a>
            </li>
        </ul>
    </div>
    <!-- End Sidebar -->
    <div class="clearfix"></div>
    </div>
    <!-- Sidebar -left -->
</div>