<?php $__env->startSection('contents'); ?>
<div class="container-fluid px-lg-5 py-4 skip-nav" style="min-height: 700px">
    <div class="row">
        <div class="col-lg-8">
       <div class="desc bg-brand p-3">
         <h2 class="title py-1 color-brand"><?php echo e($data->title); ?></h2>
         <h3 class="title py-1 color-brand"><?php echo e($data->sub_title); ?></h3>
         <h6 class="text-brand-dark py-1"><strong>Vacancy</strong></h6>
         <h6 class="text-brand-dark py-1"><?php echo e($data->vacancy); ?></h6>
         <h6 class="text-brand-dark py-1"><strong>Designation</strong></h6>
         <h6 class="text-brand-dark py-1"><?php echo e($data->designation); ?></h6>
         
         <?php echo $data->description; ?>

       </div>
     </div>
     <div class="col-lg-4">
       <div class="row mb-2">
         <div class="col-lg-12 bg-brand py-4">
          <?php if(Session::has('message')): ?>
          <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>">
            <?php echo e(Session::get('message')); ?>

            <span style="float:right;cursor:pointer;" onclick="hideAlert()"><i class="fas fa-times-circle"></i></span>
          </p>
          <?php endif; ?>
          <form method="POST" action="<?php echo e(route('frontend::jobApply')); ?>"  enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
              <label class="color-brand">
                Email
              </label>
              <input type="email" name="email" placeholder="Your Email" class="form-control mb-4" required>
              <input type="hidden" name="job_id" class="form-control" value="<?php echo e($data->id); ?>" required>
              <label class="color-brand">
                Contact No
              </label>
              <input type="text" name="phone" placeholder="Contact No" class="form-control mb-4" required>
              <label class="color-brand">
               Attach your CV
              </label>
              <input type="file" name ="cv" class="form-control" required>
              <div class="text-center">
                <button class="mt-4 btn btn-primary" type="submit">Submit CV</button>
              </div>
           </form>
       </div>
     </div>
     <div class="row p-lg-3 bg-brand">
       <div class="col-md-12">
       <div class="com-text bg-brand">
         <h2 class="color-brand pt-2"><?php echo e($data && $data->company ? $data->company->name : null); ?></h2>
         <div class="sub-heading text-brand-dark">
           <?php echo $data && $data->company ? $data->company->short_description : null; ?>

         </div>
         <span>
           <h6 class="pt-3 text-brand-dark">
             <img loading="lazy" src="<?php echo e(asset('frontend/assets/icons/enter.png')); ?>" class="enter-icon text-brand-dark">&nbsp; More About
             <a class="color-brand" href="<?php echo e(route('frontend::company',['slug' => $data && $data->company ? $data->company->slug : null])); ?>">IFAD Autos</a>
           </h6>
         </span>
       </div>
     </div>
   </div>
   </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
  p,ul li{
    color:dimgrey
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
  function hideAlert(){
    $(".alert").hide();
  }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifadgrou/public_html/resources/views/frontend/career/job-details.blade.php ENDPATH**/ ?>