<?php $__env->startSection('contents'); ?>
<div class="container-fluid skip-nav pt-5">
	<div class="row">
		<div class="col-lg-12 text-center">
			<a href="<?php echo e(route('frontend::gallery')); ?>" style="border: 1px solid #f1f1f1;" class="btn btn-shadow rounded-pill px-3 mb-2 mb-lg-0">Photos</a>
			<a href="<?php echo e(route('frontend::video')); ?>" class="btn btn-primary btn-shadow rounded-pill px-3 mb-2 mb-lg-0">Videos</a>
		</div>
	</div>
</div>
<div class="container-fluid px-lg-5 py-4" style="min-height: 700px">
	<div class="row">
		<?php $__currentLoopData = $videoDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<a class="col col-lg-3 gallery" data-fancybox="video-gallery" href="<?php echo e($video->link); ?>">
				<img class='w-100' src="<?php echo e(asset($video->image)); ?>">
				<h6 class="pt-3"><?php echo e($video->title); ?></h6>
			</a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
	.gallery{
		cursor: pointer;
		transition: transform .2s;
	}
	.gallery:hover{
		transform: scale(1.03);
	}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/optaefuh/public_html/sandbox/ifad-final/resources/views/frontend/gallery/video.blade.php ENDPATH**/ ?>