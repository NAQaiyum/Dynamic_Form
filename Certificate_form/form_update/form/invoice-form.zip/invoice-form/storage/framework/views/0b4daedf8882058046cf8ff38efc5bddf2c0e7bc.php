<form method="POST" action="<?php echo e(route('slider::save')); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title"><?php echo e($title); ?></h4>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Cover* <span style="color:tomato">(1920X700)</span></label> <br />
                        <img src="<?php echo e(asset($data ? $data->cover : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="cover">
                        <input type="file" class="form-control" accept="image/png, image/gif, image/jpeg" name="cover" onchange="document.getElementById('cover').src = window.URL.createObjectURL(this.files[0])">
                    </div>
                </div>
                <div class="col-md-6">
                    
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Slider Type*</label>
                        <select class="form-control" name="slider_type" required>
                            <option value="">Select Slider Type</option>
                            <option value="1" <?php echo e($data && $data->slider_type == 1 ? 'selected' : null); ?>>Main Slider</option>
                            <option value="2" <?php echo e($data && $data->slider_type == 2 ? 'selected' : null); ?>>Secondary Slider</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Title</label>
                        <input type="text" class="form-control" name="title" placeholder="Title" value="<?php echo e($data ? $data->title : null); ?>">
                        <input type="hidden" class="form-control" name="id" placeholder="id" value="<?php echo e($data ? $data->id : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Sub Title</label>
                        <input type="text" class="form-control" name="sub_title" placeholder="Sub Title" value="<?php echo e($data ? $data->sub_title : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Video</label>
                        <textarea class="form-control" name="video" placeholder="Video"><?php echo e($data ? $data->video : null); ?></textarea>
                    </div>
                </div>
                <!--<div class="col-md-6">-->
                <!--    <div class="mb-3">-->
                <!--        <label for="field-1" class="form-label">Link</label>-->
                <!--        <input type="url" class="form-control" name="link" placeholder="Link" value="<?php echo e($data ? $data->link : null); ?>">-->
                <!--    </div>-->
                <!--</div>-->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Placement</label>
                        <input type="number" class="form-control" name="placement" placeholder="Placement" value="<?php echo e($data ? $data->placement : null); ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-info waves-effect waves-light">Save changes</button>
        </div>
    </div>
</form><?php /**PATH /home/ifadgrou/public_html/resources/views/admin/slider/form.blade.php ENDPATH**/ ?>