<nav class="navbar navbar-expand-lg navbar-light bg-brand" id="mainNav">
    <div class="container-fluid px-5">
        <a class="navbar-brand fw-bold" href="<?php echo e(route('frontend::home')); ?>">
            <img src="<?php echo e(asset(SiteSetting()->logo_header)); ?>" />
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
  
            <i class="bi-list"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ms-auto me-4 my-3 my-lg-0 m-center">
                  <li class="nav-item">
                    <a class="nav-link me-lg-3 <?php echo e((Request::route()->getName() == 'frontend::home' || Request::route()->getName() == NULL) ? 'active' : null); ?>" href="<?php echo e(route('frontend::home')); ?>">
                      Home
                    </a>
                  </li>
                  <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle <?php echo e((Request::route()->getName() == 'frontend::about' || Request::route()->getName() == 'frontend::management') ? 'active' : null); ?> " href="#" id="navbarDropdown1" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                      About
                      </a>
                      <ul class="dropdown-menu" aria-labelledby="navbarDropdown1" style="min-width: 15rem;">
                          <li class="nav-item"><a class="nav-link me-lg-3" href="<?php echo e(route('frontend::about')); ?>">Who We Are</a></li>
                          <li class="nav-item"><a class="nav-link me-lg-3" href="<?php echo e(route('frontend::management')); ?>">BOD and Leadership</a></li>
                      </ul>
                  </li>
                  <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle <?php echo e((Request::route()->getName() == 'frontend::company') ? 'active' : null); ?> " href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                          Companies
                      </a>
                      <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <?php $__currentLoopData = getCompanies($data = 'main_menue'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li class="nav-item"><a class="nav-link me-lg-3" href="<?php echo e(route('frontend::company',['slug' => $company->slug])); ?>"><?php echo e($company->name); ?></a></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </li>
                  <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle <?php echo e((Request::route()->getName() == 'frontend::news') || (Request::route()->getName() == 'frontend::social') ? 'active' : null); ?>" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                          Media Center
                      </a>
                      <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <li class="nav-item"><a class="nav-link me-lg-3" href="<?php echo e(route('frontend::news')); ?>">News & Events</a></li>
                          <li class="nav-item"><a class="nav-link me-lg-3" href="<?php echo e(route('frontend::social')); ?>">Social Media</a></li>
                      </ul>
                  </li>
                  <li class="nav-item"><a class="nav-link me-lg-3 <?php echo e((Request::route()->getName() == 'frontend::gallery') ? 'active' : null); ?>" href="<?php echo e(route('frontend::gallery')); ?>">Gallery</a></li>
                  <li class="nav-item">
                    <a class="nav-link me-lg-3 <?php echo e((Request::route()->getName() == 'frontend::career') || (Request::route()->getName() == 'frontend::job') || (Request::route()->getName() == 'frontend::job-details') ? 'active' : null); ?>" href="<?php echo e(route('frontend::career')); ?>">Career
                    </a>
                  </li>
                
            </ul>
            <a href="<?php echo e(route('frontend::contact')); ?>" class="btn btn-primary btn-shadow rounded-pill px-3 mb-2 mb-lg-0">
                <span class="d-flex align-items-center">
                    <i class="bi-chat-text-fill me-2"></i>
                    <span class="small">Contact Us</span>
                </span>
            </a>
        </div>
    </div>
</nav><?php /**PATH /home/ifadgrou/public_html/resources/views/layouts/includes/header.blade.php ENDPATH**/ ?>