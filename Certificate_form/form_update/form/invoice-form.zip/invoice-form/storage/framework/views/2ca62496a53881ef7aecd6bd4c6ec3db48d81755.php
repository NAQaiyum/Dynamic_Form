
<?php $__env->startSection('content'); ?>
<div class="row" style="margin-top: 3.5%;">
    <form method="POST" action="<?php echo e(route('my::profile_update')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title text-center">Edit <?php echo e($employee->name); ?>`s Profile</h4>
                <!-- <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button> -->
            </div>
            <div class="modal-body p-4">
                <div class="row">
                    <div class="col-md-3">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <img src="<?php echo e(asset($employee->image ? $employee->image : 'https://thumbs.dreamstime.com/z/no-thumbnail-images-placeholder-forums-blogs-websites-148010338.jpg')); ?>" id="edit_image" style="height:250px;">
                                <input type="file" class="form-control" name="image"  accept=".png, .jpg, .jpeg" value="<?php echo e(old('image')); ?>" onchange="document.getElementById('edit_image').src = window.URL.createObjectURL(this.files[0])" >
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-2">
                                    <label for="field-1" class="form-label">Name</label>
                                    <input type="text" class="form-control" name="name" placeholder="Name" value="<?php echo e($employee->name); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-2">
                                    <label for="field-2" class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" placeholder="Email@domain.com" value="<?php echo e($employee->email); ?>">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="field-2" class="form-label">Phone</label>
                                    <input type="text" class="form-control" name="phone" placeholder="88016......82"  value="<?php echo e($employee->phone); ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary waves-effect" data-bs-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-info waves-effect waves-light">Save changes</button>
            </div>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/optaefuh/public_html/sandbox/ifad-final/resources/views/admin/profile/edit.blade.php ENDPATH**/ ?>