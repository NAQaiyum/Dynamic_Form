<?php $__env->startSection('content'); ?>
<div class="row" style="margin-top: 3.5%;">
    <div class="col-12">
        <form method="POST" action="<?php echo e(route('jobs::cv.delete')); ?>"  enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-6">
                        <h4 class="header-title"><?php echo e($title); ?></h4>
                    </div>
                    <div class="col-md-4">
                        <form method="POST" action="<?php echo e(route('jobs::cv')); ?>"  enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <div class="row">
                                    <div class="col-md-8 px-0">
                                        <input type="text" class="form-control" name="search" placeholder="search by Email or phone" id="search">
                                    </div>
                                    <div class="col-md-4 px-0">
                                        <button type="button" class="btn btn-primary" onclick=getSearchData()>Search<button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this item?');"><i class="fas fa-trash"></i> Delete </button>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table id="scroll-horizontal-datatable" class="table w-100 nowrap">
                    <thead>
                        <tr>
                            <th>  </th>
                            <th> SL </th>
                            <th> Company </th>
                            <th> Title </th>
                            <th> CV </th>
                            <th> Phone </th>
                            <th> Email </th>
                            <th> Download </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($getDatas) > 0): ?>
                        <?php $__currentLoopData = $getDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <input class="form-check-input" type="checkbox" name="id[]" value="<?php echo e($data->id); ?>"> </td>
                            <td> <?php echo e($loop->index+1); ?> </td>
                            <td> <?php echo e($data->job && $data->job->company ? $data->job->company->name : null); ?> </td>
                            <td> <?php echo e($data->job ? $data->job->title : null); ?> </td>
                            <td> <a href="<?php echo e(asset($data->cv)); ?>" target="_blank" style="color:tomato"><i class="fas fa-file-pdf"></i> </a></td>
                            <td> <?php echo e($data->phone); ?> </td>
                            <td> <?php echo e($data->email); ?> </td>
                            <td> 
                                <a class="btn btn-info" href="<?php echo e(asset($data->cv)); ?>" download="<?php echo e($data->email); ?>"> <i class="fas fa-download"></i> </a>
                                <a class="btn btn-warning" href="<?php echo e(asset($data->cv)); ?>"> <i class="fas fa-eye"></i> </a> 
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        <tr>
                            <th colspan="8" class="text-center"> CV not Found! </th>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php echo e($getDatas->links( "pagination::bootstrap-4")); ?>

            </div>
        </div>
        </form>
    </div>
</div>
<!-- Modal -->
<div id="create" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg" id="form">
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<!--<script src="<?php echo e(asset('assets/js/pages/datatables.init.js')); ?>"></script>-->
<script>
    function getForm(id){
        
        $.ajax({
            url: "<?php echo e(url('admin/career/jobs/form')); ?>",
            method: 'get',
            data:{ id:id },
            success: function(result){
                $('#form').html(result);
            }
        });
    }
    function getSearchData(){
        var search = $('#search').val();
        var job_id = <?php echo e($job_id ? $job_id : 0); ?>;
        $.ajax({
            url: "<?php echo e(url('admin/career/jobs/cv')); ?>",
            method: 'get',
            data:{ search:search,job_id:job_id },
            success: function(result){
                $('#scroll-horizontal-datatable').find('tbody').html(result);
            }
        });
    }
    function showLink(e){
        if(e.value == 1){
            $('#link').show();
        }else{
            $('#link').hide();
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/optaefuh/public_html/sandbox/ifad-final/resources/views/admin/job/cv.blade.php ENDPATH**/ ?>