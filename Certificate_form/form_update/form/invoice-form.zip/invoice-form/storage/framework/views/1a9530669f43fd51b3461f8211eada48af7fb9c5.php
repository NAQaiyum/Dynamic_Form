
<?php $__env->startSection('content'); ?>
<div class="row" style="margin-top: 3.5%;">
    <div class="col-6">
        <div class="card">
            <div class="card-body">
                <div class="col-md-12" style="overflow-x: scroll;">
                    <center>
                        <img src="<?php echo e(asset($employee->image ? $employee->image : 'https://thumbs.dreamstime.com/z/no-thumbnail-images-placeholder-forums-blogs-websites-148010338.jpg')); ?>" style="height:250px;">
                    </center>
                    <table class="table">
                        <tr>
                            <th>Name</th>
                            <th>:</th>
                            <th><?php echo e($employee->name); ?></th>
                        </tr>
                        <tr>
                            <th>Email</th>
                            <th>:</th>
                            <th><?php echo e($employee->email); ?></th>
                        </tr>
                        <tr>
                            <th>Phone</th>
                            <th>:</th>
                            <th><?php echo e($employee->phone); ?></th>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/datatables.init.js')); ?>"></script>
<script>
    $(".scroll-horizontal-datatable")
    .DataTable(
        {scrollX:!0,
            language:{
                paginate:{
                    previous:"<i class='mdi mdi-chevron-left'>",
                    next:"<i class='mdi mdi-chevron-right'>"
                }
            },drawCallback:function(){
                $(".dataTables_paginate > .pagination")
                .addClass("pagination-rounded")
            }
        }
    )
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/asiaticexp/Sites/www/comProjects/ifad/ifadweb/resources/views/admin/profile/view.blade.php ENDPATH**/ ?>