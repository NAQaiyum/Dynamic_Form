<footer class="footer" style="padding:0px;">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <?php echo e(SiteSetting() ? SiteSetting()->copyright : null); ?> <a href="">Spellbound</a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /Applications/MAMP/htdocs/meshkat/invoice-form/resources/views/layouts/footer.blade.php ENDPATH**/ ?>