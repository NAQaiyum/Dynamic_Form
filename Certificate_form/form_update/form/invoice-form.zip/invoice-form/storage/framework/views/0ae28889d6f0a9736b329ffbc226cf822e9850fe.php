<?php $__env->startSection('contents'); ?>
<header class="masthead skip-nav w-100" style="overflow: hidden;">
  <div class="container-fluid g-0">
    <div class="row">
      <div class="slider-one">
        <?php $__currentLoopData = $sliders_main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mSlider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="slide">
          <div class="overlay">
            <img src="<?php echo e(asset($mSlider->cover)); ?>" class="img-fluid">
            <div class="video-text">
              <?php if($mSlider->title): ?>
              <span><?php echo e($mSlider->title); ?></span>
              <?php endif; ?>
            </div>
            <?php if($mSlider->link): ?>
            <div class="video-link text-end">
              <button class="btn btn-default ifad_videos" id="ifad_videos" data-bs-toggle="modal" data-bs-target="#videoModal">
                <img src="<?php echo e(asset('frontend/assets/icons/play1.png')); ?>" alt="..." style="width:48px; display: inline;">
                <span>Watch Video</span>
              </button>
            </div>
            <?php endif; ?>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</header>
<!-- Quote aside-->
<div class="container-fluid px-lg-5 pt-lg-4">
  <div class="row px-lg-3 pt-4">
    <div class="col-md-3 mb-3">
      <div class="border-right testimonial animateit bg-brand pt-3 pb-1">
        <center>
          <img src="<?php echo e(asset('frontend/assets/icons/company.png')); ?>" />
          <h4 class="color-brand pt-3">1985</h4>
          <p class="text-brand-dark">Since
          </p>
        </center>
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <div class="border-right testimonial animateit bg-brand pt-3 pb-1">
        <center>
          <img src="<?php echo e(asset('frontend/assets/icons/employee.png')); ?>" />
          <h4 class="color-brand pt-3">3000+</h4>
          <p class="text-brand-dark">Number of Employees</p>
        </center>
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <div class="border-right testimonial animateit bg-brand pt-3 pb-1">
        <center>
          <img src="<?php echo e(asset('frontend/assets/icons/company.png')); ?>" />
          <h4 class="color-brand pt-3">08</h4>
          <p class="text-brand-dark">Number Sister Concerns</p>
        </center>
      </div>
    </div>
    <div class="col-md-3 mb-3">
      <div class="testimonial animateit bg-brand pt-3 pb-1">
        <center>
          <img src="<?php echo e(asset('frontend/assets/icons/customer.png')); ?>" />
          <h4 class="color-brand pt-3">100+</h4>
          <p class="text-brand-dark">Number of Export Products</p>
        </center>
      </div>
    </div>
  </div>
</div>
<?php if(count($sliders_secon) > 0): ?>
<div class="container-fluid px-lg-5 py-lg-4">
  <div class="row">
    <div class="col-md-1">
    </div>
    <div class="col-md-10">
      <div class="slider-two">
        <?php $__currentLoopData = $sliders_secon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sSlider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="slide">
          <img src="<?php echo e(asset($sSlider->cover)); ?>" class="w-100">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </div>
    </div>
    <div class="col-md-1">
    </div>
  </div>
</div>
<?php endif; ?>
</div>
<div class="container-fluid px-lg-5 py-lg-3">
  <div class="row mb-4">
    <div class="col-md-12">
      <h2 class="text-center color-brand text-upper">Message</h2>
    </div>
  </div>
  <?php $__currentLoopData = $team_messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php
  $designation = explode( ',', $message->getTeam ? $message->getTeam->designation : null)
  ?>
  <div class="row companies p-lg-3">
    <div class="col-md-6">
      <div class="msg-text">
        <p>
          <span class="text-brand-dark">
            <?php echo $message->message; ?>

          </span>
        </p>
        <p>
          <span class="color-brand mont"><?php echo e($message->getTeam ? $message->getTeam->name : null); ?></span>
          <br />
          <?php $__currentLoopData = $designation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <span class="text-brand-dark"><?php echo e($key); ?></span>
          <br />
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
        </p>
      </div>
    </div>
    <div class="col-md-1"></div>
    <div class="col-md-5">
      <div class="p-lg-3">
        <img loading="lazy" src="<?php echo e(asset($message->getTeam ? $message->image : 'frontend/assets/chairman-new.png')); ?>" class="w-100 animateit" />
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container-fluid px-lg-5 py-lg-4">
  <div class="row companies p-lg-3">
    <div class="col-md-6">
      <div class="com-text">
        <h2 class="color-brand"><?php echo e($company->name); ?></h2>
        <div class="sub-heading text-brand-dark">
          <?php echo $company->short_description; ?>

        </div>
        <span>
          <h6 class="pt-3 text-brand-dark">
            <img loading="lazy" src="<?php echo e(asset('frontend/assets/icons/enter.png')); ?>" class="enter-icon text-brand-dark">&nbsp; More About
            <a class="color-brand" href="<?php echo e(route('frontend::company',['slug' => $company->slug])); ?>"><?php echo e($company->name); ?></a>
          </h6>
        </span>
      </div>
    </div>
    <div class="col-md-1"></div>
    <div class="col-md-5">
      <div class="company-image">
        <img loading="lazy" src="<?php echo e(asset($company->thumbnail)); ?>" class="w-100 animateit" />
      </div>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="container-fluid px-lg-5 pb-lg-4">
  <div class="container-fluid px-lg-5 pb-lg-4 px-lg-5">
    <div class="row gx-5 align-items-center">
      <div class="col-md-8 offset-md-2 offset-sm-2 offset-xs-2 text-center company-logos-text">
        <h2 class="color-brand pb-3
        ">Our Companies</h2>
        <!-- <p class="text-brand-dark">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document. Lorem ipsum may be used as a placeholder before final copy is available.</p> -->
      </div>
    </div>
    <div class="row align-items-center company-logos justify-content-center">
      <?php $__currentLoopData = $companyLogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <!-- <div class="col-md-2 logo-border">
        <a href="<?php echo e(route('frontend::company',['slug' => $company->slug])); ?>"><img loading="lazy" class="img-fluid p-2 animateit" src="<?php echo e(asset($company->logo)); ?>"></a>
      </div> -->
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php $__currentLoopData = $companyLogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-3 logo-border mb-4 animateit">
        <div class="logo-container">
          <a href="<?php echo e(route('frontend::company',['slug' => $company->slug])); ?>">
            <div class="px-lg-5 px-md-2 px-sm-2">
              <img loading="lazy" class="w-100 p-lg-4 p-md-2 p-sm-2" src="<?php echo e(asset($company->logo)); ?>">
            </div>
          </a>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

  <div class="container-fluid px-lg-5 pb-lg-4" id="news-event">
    <div class="row">
      <div class="col-md-8 offset-md-2 offset-sm-2 offset-xs-2 text-center company-logos-text">
        <h2 class="color-brand">News & Events</h2>
        <!-- <p class="text-brand-dark">In publishing and graphic design, Lorem ipsum is a placeholder text commonly used to demonstrate the visual form of a document. Lorem ipsum may be used as a placeholder before final copy is available.</p> -->
      </div>
    </div>
    <div class="row">
      <div class="multiple-items">
        <?php $__currentLoopData = $getNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 py-2 px-3 slide">
          <a href="<?php echo e(route('frontend::news',['slug' => $news->slug])); ?>">
            <div class="media">
              <div class="media-image">
                <div class="image-overlay">
                  <img loading="lazy" src="<?php echo e(asset($news->thumbnail)); ?>" class="animateit image w-100" />
                </div>
              </div>
              <div class="media-text text-brand-dark pt-3">
                <p><?php echo e($news->title); ?></p>
              </div>
            </div>
          </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
  <div class="container-fluid px-lg-5 py-lg-4" id="social-media">
    <div class="row">
      <div class="col-md-8 offset-md-2 offset-sm-2 offset-xs-2 text-center company-logos-text">
        <h2 class="color-brand">Social Media Feed</h2>
        <!-- <p class="text-brand-dark"></p> -->
      </div>
    </div>
    <div class="row">
      <div class="multiple-items">
        <?php $__currentLoopData = $getSocial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 py-2 px-3 slide">
          <div class="media">
            <div class="media-image">
              <div class="image-overlay">
                <a target="_blank" href="<?php echo e(asset($social->ref)); ?>">
                  <img loading="lazy" src="<?php echo e(asset($social->thumbnail)); ?>" class="animateit image w-100" />
                </a>
              </div>
            </div>
            <div class="media-text text-brand-dark pt-3">
              <p><?php echo e($social->title); ?></p>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/optaefuh/public_html/sandbox/ifad-final/resources/views/frontend/home/index.blade.php ENDPATH**/ ?>