<div class="row">
    <div class="col-md-12">
        <h3 class="category-headding ">Categories</h3>
        <div class="headding-border"></div>
    </div>
<?php $__currentLoopData = $getData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <style>
        .badge_<?php echo e($data->id); ?>:after{
            content : "<?php echo e(substr($data->title, 1)); ?>" !important;
        }
    </style>
    <div class="col-sm-6" style="padding: 0px 15px 0px 0px ;">
        <div class="post-style1">
            <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                <!-- post image -->
                <a href="<?php echo e(route('frontend::category.index',['slug' => $data->slug])); ?>">
                    <img src="<?php echo e(asset($data->thumbnail)); ?>" class="img-responsive" alt="" style="aspect-ratio : 4/3">
                </a>
                <div class="post-info meta-info-rn">
                    <div class="slide">
                        <a target="_blank" href="<?php echo e(route('frontend::category.index',['slug' => $data->slug])); ?>" class="post-badge btn_eight badge_<?php echo e($data->id); ?>"><?php echo e(mb_substr($data->title, 0, 1)); ?></a>
                    </div>
                </div>
            </div>
            <!-- post title -->
            <h4><a href="<?php echo e(route('frontend::category.index',['slug' => $data->slug])); ?>"><?php echo e($data->title); ?></a></h4>
            
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH /Applications/MAMP/htdocs/meshkat/car/resources/views/frontend/home/includes/category.blade.php ENDPATH**/ ?>