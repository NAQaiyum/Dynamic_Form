<?php $__env->startSection('contents'); ?>
<div class="container-fluid px-lg-5 py-4 skip-nav" style="min-height: 700px">
	<div class="row">
        <!-- <div class="col-lg-12 pt-lg-3">
            <div class="side-bar">
                <p class="text-brand-dark py-3 px-lg-2 bg-brand effect-hover"><a href="about.php">Who We Are</a></p>
                <p class="text-brand-dark py-3 px-lg-2 bg-brand"><a class="text-brand-dark" href="management.php">Management</a></p>
            </div>
        </div> -->
        <div class="col-md-12 pt-lg-3 text-center">
        	<h3 class="title color-brand">Welcome to IFAD Careers</h3>
        	<p>A place that challenges you to thrive.</p>
        </div>
    </div>
    <div class="row pt-3 text-center">
    	<h3 class="title color-brand">Why be a part of IFAD FAMILY?</h3>
    	<?php $__currentLoopData = $getDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	<div class="col-lg-4 text-center pt-lg-5">
    		<div class="p-3 bg-brand effect-hover">

    			<img src="<?php echo e(asset($data->image)); ?>" class="w-100">
    			<h5 class="py-2 title color-brand"><?php echo e($data->title); ?></h5>
    			<p><?php echo e($data->short_description); ?></p>
    		</div>
    	</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="row mt-4">
        <div class="col-lg-12">
             <div class="text-center">
                 <a href="<?php echo e(route('frontend::job')); ?>"><button class="mt-4 btn btn-primary">Current Job Opening</button></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
	.effect-hover{
		transition: transform 0.2s;
	}
	.effect-hover:hover{
		transform: scale(1.01);
	}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifadgrou/public_html/group/resources/views/frontend/career/index.blade.php ENDPATH**/ ?>