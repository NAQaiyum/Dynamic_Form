<footer class="bg-brand">
	<div class="container-fluid p-5">
		<div class="row">
			<div class="col-md-3">
				<img class="logo" src="<?php echo e(asset(SiteSetting()->logo_footer)); ?>" />
				<div class="social py-3">
					<?php $__currentLoopData = SocialSetting(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<span>
						<a href="<?php echo e($social->link); ?>" title="<?php echo e($social->title); ?>" target="_blank"><img src="<?php echo e(asset($social->icon)); ?>"></a>
					</span>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<div class="col-md-6">
				<div class="footer-nav">
					<h5 class="color-brand"> More Links </h5>
					<div class="row footer">
						<div class="col-md-3">
							<div class="mt-1">
								<a class="text-brand-dark" href="<?php echo e(route('frontend::home')); ?>"> Home </a>
							</div>
							<div class="mt-1">
								<a class="text-brand-dark" href="<?php echo e(route('frontend::about')); ?>"> About us </a>
							</div>
							<div class="mt-1">
								<a class="text-brand-dark" href="<?php echo e(route('frontend::management')); ?>"> BOD </a>
							</div>
							<div class="mt-1">
								<a class="text-brand-dark" href="<?php echo e(route('frontend::career')); ?>"> Career </a>
							</div>
						</div>
						<div class="col-md-4">
							<?php $dt = getCompanies($data = 'footer_menue') ?>
							<?php $__currentLoopData = $dt->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="mt-1">
								<a class="text-brand-dark" href="<?php echo e(route('frontend::company',['slug' => $company->slug])); ?>"> <?php echo e($company->name); ?> </a>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="col-md-5">
							<?php $__currentLoopData = $dt->skip(4)->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="mt-1">
								<a class="text-brand-dark" href="<?php echo e(route('frontend::company',['slug' => $company->slug])); ?>"> <?php echo e($company->name); ?> </a>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="footer-contact">
					<h5 class="color-brand"> Contact </h5>
					<ul class="list-unstyled text-brand-dark">
						<li> IFAD Tower </li>
						<li> <?php echo e(SiteSetting()->address); ?> </li>
						<li><a href="tel:<?php echo e(SiteSetting()->phone); ?> " class="text-brand-dark"> Tel:  <?php echo e(SiteSetting()->phone); ?>  </a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	<div class="footer-bottom bg-brand-dark">
		<div class="container-fluid pt-3 pb-1 px-5">
			<div class="row text-white">
				<div class="col-md-8">
					<span>© Copyright 2022 IFADGROUP. All Rights Reserved. | </span>
					<span class="text-brand-dark">
					    <a class="text-brand-dark"href="https://optimumservices.com.bd" target="_blank" rel="noindex, nofolow"> Developed by OSL </a>
					</span>
				</div>
				<div class="col-md-4">
					<p style="text-align:right">
						<a href="<?php echo e(route('frontend::privacy')); ?>"> Privacy & Policy </a>
					</p>
				</div>
			</div>
		</div>
	</div>
	<span onclick="topFunction()" id="myBtn" title="Go to top"><img src="<?php echo e(asset('frontend/assets/backtotop.png')); ?>"></span>
</footer>
<div class="modal fade" id="videoModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-xl">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="exampleModalLabel">IFAD Group Corporate Video</h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" id="btn-close"></button>
			</div>
			<div class="modal-body" id="video">

			</div>
		</div>
	</div>
</div><?php /**PATH /home/ifadgrou/public_html/group/resources/views/layouts/includes/footer.blade.php ENDPATH**/ ?>