<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="noindex,nofollow">
    <title>Ifad Group Corporate Website</title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/favicon.ico')); ?>" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Mulish:ital,wght@0,300;0,500;0,600;0,700;1,300;1,500;1,600;1,700&amp;display=swap" rel="stylesheet" />
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css2?family=Poppins&amp;display=swap' rel='stylesheet' type='text/css'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css" integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="<?php echo e(asset('frontend/css/styles.css')); ?>?id=<?php echo rand(1,1000); ?>" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.css">
	<style>
		iframe{
			width:100%;
			min-height:500px;
		}
	</style>
	<?php echo $__env->yieldContent('css'); ?>
    
</head>
<body id="page-top">
	<?php echo $__env->make('layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<?php echo $__env->yieldContent('contents'); ?>

    <?php echo $__env->make('layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>
  AOS.init();
</script>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<!-- Core theme JS-->
<!-- <script src="js/scripts.js"></script> -->
<!-- slick -->
<script src="<?php echo e(asset('frontend/js/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0/dist/fancybox.umd.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function(){
// make it as accordion for smaller screens
if (window.innerWidth > 992) {
    document.querySelectorAll('.navbar .nav-item').forEach(function(everyitem){
        everyitem.addEventListener('mouseover', function(e){
            let el_link = this.querySelector('a[data-bs-toggle]');
            if(el_link != null){
                let nextEl = el_link.nextElementSibling;
                el_link.classList.add('show');
                nextEl.classList.add('show');
            }
        });
        everyitem.addEventListener('mouseleave', function(e){
            let el_link = this.querySelector('a[data-bs-toggle]');
            if(el_link != null){
                let nextEl = el_link.nextElementSibling;
                el_link.classList.remove('show');
                nextEl.classList.remove('show');
            }
        })
    });
}
// end if innerWidth
}); 
</script>
<script type="text/javascript">
    $(document).ready(function(){
      $('.slider-one').slick({
        autoplay: true,
        arrows: false,
        draggable: true,
        lazyLoad: 'ondemand',
        dots: true,
        arrows: false

    });
	$('.slider-two').slick({
	autoplay: true,
	arrows: false,
	draggable: true,
	lazyLoad: 'ondemand',
	dots: true,
	arrows: false
	});

	$('.slider-three').slick({
	autoplay: true,
	arrows: false,
	draggable: true,
	lazyLoad: 'ondemand'
	});
    });
</script>
<script>
    document.getElementById("ifad_videos").onclick = displayData;
    document.getElementById("ifad_videos1").onclick = displayData;
    document.getElementById("ifad_videos2").onclick = displayData;
    document.getElementById("ifad_videos3").onclick = displayData;
    document.getElementById("ifad_videos4").onclick = displayData;
    document.getElementById("ifad_videos5").onclick = displayData;
    document.getElementById("ifad_videos6").onclick = displayData;
    document.getElementById("btn-close").onclick = hideData;
    function displayData() {
        document.getElementById("video").innerHTML = '<iframe id="video_iframe" width="100%" height="500px" src="https://www.youtube.com/embed/ErcmQd3JJJw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>';
    }
    function hideData() {
        document.getElementById("video_iframe").remove();
    }
</script>
<script>
    //Get the button:
	mybutton = document.getElementById("myBtn");

	// When the user scrolls down 20px from the top of the document, show the button
	window.onscroll = function() {scrollFunction()};

	function scrollFunction() {
	if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
		mybutton.style.display = "block";
	} else {
		mybutton.style.display = "none";
	}
	}

	// When the user clicks on the button, scroll to the top of the document
	function topFunction() {
		document.body.scrollTop = 0; // For Safari
		document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
	}
</script>
	<?php echo $__env->yieldContent('js'); ?>
    
</body>
</html><?php /**PATH /Users/asiaticexp/Sites/www/comProjects/ifad/ifadweb/resources/views/layouts/frontend.blade.php ENDPATH**/ ?>