<form method="POST" action="<?php echo e(route('video::save')); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title"><?php echo e($title); ?></h4>
            <button type="button" class="btn-close fas fa-times" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Cover <span style="color:tomato">(16:9)</span></label> <br />
                        <img src="<?php echo e(asset($data ? $data->cover : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="cover">
                        <input type="file" class="form-control" accept="image/png, image/gif, image/jpeg" name="cover" onchange="document.getElementById('cover').src = window.URL.createObjectURL(this.files[0])">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Thumbnail <span style="color:tomato">(4:3)</span></label> <br />
                        <img src="<?php echo e(asset($data ? $data->thumbnail : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="image">
                        <input type="file" class="form-control" accept="image/png, image/gif, image/jpeg" name="image" onchange="document.getElementById('image').src = window.URL.createObjectURL(this.files[0])">
                    </div> 
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Title</label>
                        <input type="text" class="form-control" name="title" placeholder="Title" value="<?php echo e($data ? $data->title : null); ?>">
                        <input type="hidden" class="form-control" name="id" placeholder="id" value="<?php echo e($data ? $data->id : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Sub Title</label>
                        <input type="text" class="form-control" name="sub_title" placeholder="Sub Title" value="<?php echo e($data ? $data->sub_title : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Video Type</label>
                        <select name="video_type" class="form-control">
                            <option value="">Select Video Type</option>
                            <option value="1" <?php echo e($data && $data->video_type == 1 ? 'Selected' : null); ?>>Youtube</option>
                            <option value="2" <?php echo e($data && $data->video_type == 2 ? 'Selected' : null); ?>>Vidmate</option>
                            <option value="3" <?php echo e($data && $data->video_type == 3 ? 'Selected' : null); ?>>Internal</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Video Link</label>
                        <textarea class="form-control" name="video_link" placeholder="Video"><?php echo e($data ? $data->video_link : null); ?></textarea>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Video </label> <br />
                        <!-- <img src="<?php echo e(asset($data ? $data->video : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="image"> -->
                        <video width="320" height="240" controls id="video">
                            <source src="<?php echo e($data && $data->video ? asset($data->video) : null); ?>" type="video/mp4">
                            <source src="<?php echo e($data && $data->video ? asset($data->video) : null); ?>" type="video/ogg">
                            Your browser does not support the video tag.
                        </video>
                        <input type="file" class="form-control" accept="video/oog, video/mp4,audio/mp3, video/mkv " name="video" onchange="document.getElementById('video').src = window.URL.createObjectURL(this.files[0])">
                    </div> 
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Placement</label>
                        <input type="number" class="form-control" name="placement" placeholder="Placement" value="<?php echo e($data ? $data->placement : null); ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-info waves-effect waves-light">Save changes</button>
        </div>
    </div>
</form><?php /**PATH /Applications/MAMP/htdocs/comProjects/riseofbang/resources/views/admin/video/form.blade.php ENDPATH**/ ?>