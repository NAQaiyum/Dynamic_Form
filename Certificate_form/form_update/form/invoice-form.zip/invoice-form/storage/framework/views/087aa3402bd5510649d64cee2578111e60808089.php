<!-- Video News Area
    ============================================ -->
    <section class="video-post-inner">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <h3 class="category-headding ">VIDEO POST</h3>
                <div class="headding-border"></div>
            </div>
            <?php $__currentLoopData = $getVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-4">
                <div class="post-style1">
                    <div class="post-wrapper wow fadeIn" data-wow-duration="1s">
                        <!-- post image -->
                        <a href="<?php echo e(route('frontend::video.details',['slug'=>$video->slug])); ?>" class="video-img-icon">
                            <i class="fa fa-play"></i>
                            <img src="<?php echo e(asset($video->thumbnail ? $video->thumbnail :'frontend/images/video-02.jpg')); ?>" alt="" class="img-responsive" style="aspect-ratio : 4/3">
                        </a>
                    </div>
                    <!-- post title -->
                    <h3><a href="<?php echo e(route('frontend::video.details',['slug'=>$video->slug])); ?>"><?php echo e($video->title); ?></a></h3>
                    <div class="post-title-author-details">
                        <div class="date">
                            <ul>
                                <li><img src="<?php echo e(asset('frontend/images')); ?>/comment-02.jpg" class="img-responsive" alt=""></li>
                                <li>By <a title="" href="#"><span>Naeem Khan</span></a> --</li>
                                <li><a title="" href="#">Oct 6, 2016</a> --</li>
                                <li><a title="" href="#"><span>275 Comments</span></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</section><?php /**PATH /Applications/MAMP/htdocs/comProjects/riseofbang/resources/views/frontend/home/includes/video.blade.php ENDPATH**/ ?>