

<div class="articale-list">
    <h3 class="category-headding "><?php echo e($title); ?></h3>
    <div class="headding-border"></div>
    <!--Post list-->
    <?php $__currentLoopData = $getData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="post-style2 wow fadeIn" data-wow-duration="1s">
        <div class="col-md-5">
            <a href="<?php echo e(route('frontend::news.details',['slug'=>$data->slug])); ?>">
                <img src="<?php echo e(asset($data && $data->thumbnail ? $data->thumbnail : 'frontend/images/category/category-post-11.jpg')); ?>" alt="" style="width : 100%">
            </a>
        </div>
        <div class="col-md-7">
            <div class="post-style2-detail">
                <h5><a href="<?php echo e(route('frontend::news.details',['slug'=>$data->slug])); ?>" title=""><?php echo e($data->title); ?></a></h5>
                <div class="date">
                    <ul>
                        <li><img src="<?php echo e(asset('frontend/images/comment-01.jpg')); ?>" class="img-responsive" alt=""></li>
                        <li>By <a title="" href="#"><span><?php echo e($data->auth); ?></span></a> --</li>
                        <li><a title="" href="#"><?php echo e($data->news_date ? date('M d, Y', strtotime($data->news_date)) : null); ?></a> --</li>
                        <li><a title="" href="#"><span>275 Comments</span></a></li>
                    </ul>
                </div>
                <p><?php echo e(substr($data->sub_title, 0,120)); ?></p>
                <a href="<?php echo e(route('frontend::news.details',['slug'=>$data->slug])); ?>" class="btn btn-style">Reade more</a>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="row">
    <div class="col-sm-12">
        <div class="banner">
            <img src="<?php echo e(asset('frontend/images/top-bannner2.jpg')); ?>" class="img-responsive center-block" alt="">
        </div>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/meshkat/car/resources/views/frontend/home/includes/article.blade.php ENDPATH**/ ?>