<footer class="footer" style="padding:0px;">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
                <?php echo e(SiteSetting() ? SiteSetting()->copyright : null); ?> <a href="">Optimum</a>
            </div>
        </div>
    </div>
</footer><?php /**PATH /Users/asiaticexp/Sites/www/comProjects/osl/resources/views/layouts/footer.blade.php ENDPATH**/ ?>