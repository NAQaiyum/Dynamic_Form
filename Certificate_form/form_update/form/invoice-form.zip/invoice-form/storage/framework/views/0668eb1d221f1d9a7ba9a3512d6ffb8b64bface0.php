<!-- Vendor js -->
<script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>

<!-- App js-->
<script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<script src="https://cdn.ckeditor.com/ckeditor5/30.0.0/classic/ckeditor.js"></script>

<?php echo $__env->yieldContent('js'); ?>
<?php echo notifyJs(); ?><?php /**PATH /Applications/MAMP/htdocs/meshkat/car/resources/views/layouts/js.blade.php ENDPATH**/ ?>