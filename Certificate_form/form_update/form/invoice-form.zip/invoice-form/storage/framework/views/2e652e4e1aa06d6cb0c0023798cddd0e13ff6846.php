<?php
    $sampleshortDes = "<p>Education &nbsp;&nbsp;:&nbsp;&nbsp;Bachelor of Business Administration from a reputed university.<br>Experience Requirements &nbsp;&nbsp;:&nbsp;&nbsp; Minimum &nbsp; &nbsp;3 &nbsp;Year/s</p>";
    $sampleDes      = "<p><strong>Job Responsibilites</strong></p><ul><li>Report to Branch Manager</li><li>Have capacity to run individually a showroom/outlet where another couple of associate are engaged for daily retail sales.</li><li>To work as the key person of the show-room to enhance and develop the sales &amp; marketing as well as to achieve organizational goals as awarded by the management.</li><li>Should possess adequate knowledge and experience in sales &amp; marketing and be capable of gain attraction from potential customers.</li><li>Should be able to work under pressure.</li><li>Make sure that all reports (Daily, week ending, and month ending business reports) are submitted to head office in time by communicating with branch manager.</li><li>Should be prepared to work as task force employee at any place in Bangladesh.</li><li>Sales target should be achieved monthly, quarterly and yearly.</li><li>Maintaining all documentation and records correctly on daily basis.</li><li>Enhance more revenue using upselling techniques, extended customer relationship and personalized service.</li><li>Provide proper after-sales service to get a satisfied customer and create every customer database.</li><li>Take an effective part for company's sales promotion.</li></ul><p><strong>Employment Status</strong></p><p>Full-time</p><p><strong>Educational Requirements</strong></p><ul><li>Bachelor degree in any discipline</li><li>Academic qualification minimum graduation</li><li>Qualification might be considered for extremely skilled candidate</li><li>Skills Required: Computer skill and Working knowledge of office equipment like laptop, Computer skills with Microsoft Excel, Proficient Computer skills</li></ul><p><strong>Job Location</strong></p><p>Anywhere in Bangladesh</p><p><strong>Salary</strong></p><p>Negotiable</p>";
?>
<form method="POST" action="<?php echo e(route('jobs::save')); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title"><?php echo e($title); ?></h4>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-4">
            <div class="row">
                <!--<div class="col-md-12">-->
                <!--    <div class="mb-3">-->
                <!--        <label for="field-1" class="form-label">Image</label> <br />-->
                <!--        <img src="<?php echo e(asset($data && $data->image ? $data->image : 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg' )); ?>" style="height: 150px; margin-bottom:10px;" id="image">-->
                <!--        <input type="file" class="form-control" accept="image/png, image/gif, image/jpeg" name="image" onchange="document.getElementById('image').src = window.URL.createObjectURL(this.files[0])">-->
                <!--    </div>-->
                <!--</div>-->
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Title</label>
                        <input type="text" class="form-control" name="title" placeholder="Title" value="<?php echo e($data ? $data->title : null); ?>">
                        <input type="hidden" class="form-control" name="id" placeholder="Name" value="<?php echo e($data ? $data->id : null); ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Sub Title</label>
                        <input type="text" class="form-control" name="sub_title" placeholder="Sub Title" value="<?php echo e($data ? $data->sub_title : null); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Company</label>
                        <select class="form-control" name="company_id">
                            <option value=""> Select Company </option>
                            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($company->id); ?>" <?php echo e($data && $data->company_id == $company->id ? 'Selected' : null); ?>> <?php echo e($company->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Vacancy</label>
                        <input type="number" class="form-control" name="vacancy" placeholder="Vacancy" value="<?php echo e($data ? $data->vacancy : null); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Designation</label>
                        <input type="text" class="form-control" name="designation" placeholder="Designation" value="<?php echo e($data ? $data->designation : null); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Placement</label>
                        <input type="number" class="form-control" name="placement" placeholder="Placement" value="<?php echo e($data ? $data->placement : null); ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Deadline</label>
                        <input type="date" class="form-control" name="deadline" placeholder="Deadline" value="<?php echo e($data ? $data->deadline : null); ?>">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Short Description</label>
                        <textarea class="form-control" name="short_description" id="short_description" placeholder="Short Description"><?php echo e($data ? $data->short_description : $sampleshortDes); ?></textarea>
                    </div>
                </div>
                
                <div class="col-md-12">
                    <div class="mb-3">
                        <label for="field-1" class="form-label">Description</label>
                        <textarea class="form-control" name="description" id="description" placeholder="Description"><?php echo e($data ? $data->description : $sampleDes); ?></textarea>
                    </div>
                </div>
                
            </div>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-info waves-effect waves-light">Save changes</button>
        </div>
    </div>
</form>
<script>
    ClassicEditor
        .create( document.querySelector( '#short_description' ))
        .catch( error => {
            console.error( error );
        });
    ClassicEditor
        .create( document.querySelector( '#description' ))
        .catch( error => {
            console.error( error );
        });
</script>
<style>
.ck ul li{
    list-style-type: disc !important;
    margin-left: 30px;
}
</style>
<?php /**PATH /home/ifadgrou/public_html/resources/views/admin/job/form.blade.php ENDPATH**/ ?>