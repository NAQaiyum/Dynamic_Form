<?php $__env->startSection('content'); ?>
<div class="row" style="margin-top: 3.5%;">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-10">
                        <h4 class="header-title"><?php echo e($title); ?></h4>
                    </div>
                    <div class="col-md-2">
                        <p class="btn btn-primary waves-effect waves-light" data-bs-toggle="modal" data-bs-target="#create"  onclick="getForm(0)"><i class="fa fa-plus"></i> create</p>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <table id="scroll-horizontal-datatable" class="table w-100 nowrap">
                    <thead>
                        <tr>
                            <th> SL </th>
                            <th> Media </th>
                            <th> Title </th>
                            <th> Sub Title </th>
                            <th> Type </th>
                            <th> Placement </th>
                            <th> Action </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $getDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($loop->index+1); ?> </td>
                            <td> 
                                <?php if($data->gallery_type == 0): ?>
                                <img src="<?php echo e($data ? asset($data->image) : null); ?>" style="height: 50px;"> 
                                <?php else: ?> 
                                    <?php echo $data->link; ?>

                                <?php endif; ?>
                            </td>
                            <td> <?php echo e($data->title); ?> </td>
                            <td> <?php echo e($data->sub_title); ?> </td>
                            <td> <?php echo e($data->gallery_type == 1 ? 'Video' : 'Image'); ?> </td>
                            <td> <?php echo e($data->placement); ?> </td>
                            <td class="action">
                                <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#create" onclick="getForm(<?php echo e($data->id); ?>)" > <i class="fa fa-edit"></i> </a>
                                <a href="<?php echo e(route('gallery::delete',['id'=>$data->id])); ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this item?');"> <i class="fa fa-trash"></i> </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div id="create" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-lg" id="form">
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/datatables.init.js')); ?>"></script>
<script>
    function getForm(id){
        
        $.ajax({
            url: "<?php echo e(url('admin/gallery/form')); ?>",
            method: 'get',
            data:{ id:id },
            success: function(result){
                $('#form').html(result);
            }
        });
    }
    
    function showLink(e){
        if(e.value == 1){
            $('#link').show();
        }else{
            $('#link').hide();
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ifadgrou/public_html/resources/views/admin/gallery/index.blade.php ENDPATH**/ ?>