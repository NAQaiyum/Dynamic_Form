
<?php $__env->startSection('contents'); ?> 
<?php
use SimpleSoftwareIO\QrCode\Facades\QrCode;
?>
<form method="POST" action="<?php echo e(route('frontend::invoice.save')); ?>"  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <table class="table table-bordered table-size" style="background-color: #fbebf0;">
        <tbody>
            <tr>
                <td style="width: 50% ; height:15px">
                    1. Exporter (Name & Address)<br>
                    <div class="form-group">
                    <?php echo e($getData->ex_name); ?>

                    </div>
                    <div class="form-group">
                    <?php echo e($getData->ex_address); ?>

                    </div>
                    
                    <!-- <input type="text" placeholder="" style="width: 70%;" /><br>
                    <input type="text" placeholder="" style="width: 70%;" /> -->
                </td>
                <td rowspan="2" style="width: 50%; text-align : center; padding: 20px 40px">
                    <h6 class="pb-3">REPUBLIC OF SINGAPORE</h6>
                    <img class="pb-3" src="<?php echo e(URL('storage/logo.png')); ?>" alt="" style="width : 20%;">
                    <!-- <img src="https://justspas.com.au/wp-content/uploads/2021/01/Signature-logo.png" style="width : 30%;" id="signature_1"/> -->

                    <h4>CERTIFICATE OF ORIGIN</h4>
                    <div class="form-group pt-5 pb-5">
                        <label style="text-align : center">NO <?php echo e($getData->certificate_origin_no); ?></label>
                        <!-- <center><input type="text" class="form-control" name="certificate_origin_no" placeholder="" required style="width : 80%"></center> -->
                    </div>
                    <p>NO UNAUTHORISED ADDITION/ALTERATION MAY BE MADE TO THIS CERTIFICATE ONCE IT IS ISSUED</p>
                </td>
            </tr>
            <tr>
                <td style="height:15px">
                    2. Consignee (Name, Full Address & Country)
                    <div class="form-group">
                    <?php echo e($getData->con_name); ?>

                    </div>
                    <div class="form-group">
                    <?php echo e($getData->con_full_address); ?>

                    </div>
                    <div class="form-group">
                    <?php echo e($getData->con_country); ?>

                    </div>
                </td>
            </tr>
            <tr>
                <td style="height:15px">
                    <div class="">
                        <label>3. Departure Date </label>
                        <?php echo e($getData->dep_date); ?>

                    </div>
                </td>
                <td rowspan="5">
                    <div style="width : 80%">
                        <p style="text-aligh : justify">
                            8. DECLARATION BY THE Exporter<br>
                            We hereby declare that the details and statements provided in
                            this Certificate are true and correct.
                        </p>
                    </div>
                    <div class="column">
                        <div class="row">
                            <!-- <div class="col-md-4">
                                <img src="https://justspas.com.au/wp-content/uploads/2021/01/Signature-logo.png" style="width : 100%;" id="signature_1"/>
                            </div> -->
                            <div class="col-md-8">
                                <div class="">
                                    <lable>Signature:<lable>
                                    <img src="<?php echo e(asset($getData->signature_1)); ?>" alt="image" style="width : 20%;">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="">
                        <lable>Name:<lable>
                        <?php echo e($getData->name); ?>

                    </div>
                    <div class="">
                        <lable>Designation:<lable>
                        <?php echo e($getData->designation); ?>

                    </div>
                    <div class="">
                        <lable>Date:<lable>
                        <?php echo e($getData->date_1); ?>

                    </div>
                </td>
            </tr>
            <tr>
                <td style="height:15px">
                    4. Vessel&rsquo;s Name/Flight No. 
                    <?php echo e($getData->vessels_name); ?>

                </td>
            </tr>
            <tr>
                <td style="height:15px">
                    5. Port of Discharge  <?php echo e($getData->port_of_discharge); ?>

                </td>
            </tr>
            <tr>
                <td style="height:15px">6. Country of Final Destination <?php echo e($getData->country_destination); ?></td>
            </tr>
            <tr>
                <td style="height:15px">7. Country of Origin of Goods <?php echo e($getData->country_origin); ?></td>
            </tr>
            <tr>
                <td colspan="2" style= "padding: 0px 0px 135px 0px">
                    <div class="flex-container">
                        <div class="column left">
                            <p>9. Marks & Numbers</p>
                        </div>
            
                        <div class="column center">
                            <p>10. No. & Kind of Package<br>Description of Goods<br>(include brand names if necessary)<br><br></p>
                            <p>
                                PLASTIC<br><br>
                                - - - - - - - - - - - - - - - - - - - - - - 
                            </p>
                        </div>
            
                        <div class="column right">
                            <p>11. H.S. Code</p>
                            <?php echo e($getData->h_s_code); ?>

                        </div>
            
                        <div class="column new">
                            <p>12. Quantity & Unit</p>
                            <?php echo e($getData->quantity_unit); ?>

                        </div>
                    </div>
                </td>
            </tr>
            
            <tr>
                <td colspan="2" class="text-justify">
                    <p>13. CERTIFICATION BY THE COMPLEMENT AUTHORITY<br>
                    We hereby certify that evidence has been produced to satisfy us that the goods specified 
                    above originate in/were processed in the country shown in box 7. This Certificate is 
                    therefore issued and certified to the best of our knowledge and belief to be correct and without any
                    liability on our part.</p>

                    <div class="row">
                        <div class="col-md-6">
                            <!-- Content on the left side (if any) -->
                            <div>
                                <?php echo QrCode::size(100)->generate('https://www.youtube.com/watch?v=JSjUZig7JIU'); ?>

                            </div>
                            
                            <!-- Nested box on the right side -->
                                <div class="nested-div" >
                                    <div style="display: flex; flex-direction: column">
                                        <div style="flex-grow: 1;">
                                                
                                        </div>   
                                    </div>
                                </div>
                        </div>

                        <div class="col-md-6">
                            <!-- Nested box on the right side -->
                            <div class="nested-div" style="border: 2px solid black; padding: 10px;">
                                <div style="display: flex; flex-direction: column">
                                    <div style="display flex-grow: 1;">
                                        <img src="<?php echo e(URL('storage/logo.png')); ?>" alt="Company Logo" style="width: 10%; margin-bottom: 10px;">
                                        <p>
                                            Singapore International Chamber of Commerce.<br>
                                            6 Raffles Quay 10-01. Singapore 048580<br>
                                            Tel: +65 65000988<br>
                                            SICC SERIAL NO: 
                                        </p>
                                    </div>
                                    <div style="text-align: right;">         
                                        <img src="<?php echo e(asset('/' . $getData->signature_2)); ?>" alt="Signature" style="width: 10%;" ><br>
                                        <label>For SECRETARY - GENERAL</label>                                       
                                    </div>
                                </div>
                            </div>
                        </div>      
                    </div>   
                

                    <div class="form-group">
                        <center>
                            <label>Date:</label>
                            <?php echo e($getData->date_2); ?>

                        </center>
                    </div>
                </td>
            </tr>

        </tbody>
    </table>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\invoice-form\invoice-form\resources\views/frontend/home/details.blade.php ENDPATH**/ ?>